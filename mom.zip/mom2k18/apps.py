from django.apps import AppConfig


class mom2k18Config(AppConfig):
    name = 'mom2k18'
